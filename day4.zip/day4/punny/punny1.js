punycode = require('punycode');  
console.log(punycode.decode('maana-pta')); 