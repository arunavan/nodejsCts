punycode = require('punycode');  
console.log(punycode.encode('?-?'));  