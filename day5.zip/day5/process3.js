console.log(`Current directory: ${process.cwd()}`);  
console.log(`Uptime: ${process.uptime()}`);  