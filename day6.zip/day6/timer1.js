setInterval(function() {  
 console.log("setInterval: Hey! 1 millisecond completed!..");   
}, 1000);  