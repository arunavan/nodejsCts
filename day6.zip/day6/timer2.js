var i =0;  
console.log(i);  
setInterval(function(){  
i++;  
console.log(i);  
}, 1000);   